// DevBox extension — background service worker (Manifest V3)
//
// Registers right-click context menu actions for selected text, opening the
// matching DevBox tool in a new tab with that text pre-filled. Uses a
// base64-encoded URL parameter (?ext_prefill=...) to hand the text off,
// which the site bridges into its existing internal tool-chaining mechanism
// on load -- see assets/shared.js's bridgeExtensionPrefill().

const BASE_URL = "https://devmina.github.io/devbox";

const MENU_ITEMS = [
    { id: "devbox-json", title: "DevBox: Format as JSON", tool: "tools/json.html" },
    { id: "devbox-base64", title: "DevBox: Base64 Decode", tool: "tools/base64.html" },
    { id: "devbox-url", title: "DevBox: URL Decode", tool: "tools/url.html" },
    { id: "devbox-jwt", title: "DevBox: Decode JWT", tool: "tools/jwt.html" },
    { id: "devbox-hash", title: "DevBox: Hash this text", tool: "tools/hash.html" },
];

chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
            id: "devbox-root",
            title: "DevBox",
            contexts: ["selection"],
        });
        MENU_ITEMS.forEach(item => {
            chrome.contextMenus.create({
                id: item.id,
                parentId: "devbox-root",
                title: item.title,
                contexts: ["selection"],
            });
        });
    });
});

function handleMenuClick(info) {
    const item = MENU_ITEMS.find(m => m.id === info.menuItemId);
    if (!item || !info.selectionText) return null;

    const encoded = btoa(encodeURIComponent(info.selectionText));
    const url = `${BASE_URL}/${item.tool}?ext_prefill=${encoded}`;
    chrome.tabs.create({ url });
    return url;
}

chrome.contextMenus.onClicked.addListener(handleMenuClick);
