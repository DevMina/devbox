// DevBox extension — popup script

const BASE_URL = "https://devmina.github.io/devbox";

// A curated set of frequently-reached-for tools, not all 78 -- the popup is
// meant for quick access, not to replace the site's own search/command
// palette for the long tail.
const QUICK_TOOLS = [
    { href: "tools/json.html", label: "JSON Formatter", dot: "#3DFFA0" },
    { href: "tools/regex.html", label: "Regex Tester", dot: "#5BA4FF" },
    { href: "tools/uuid.html", label: "UUID Generator", dot: "#22D9F0" },
    { href: "tools/password.html", label: "Password Generator", dot: "#FF5E7A" },
    { href: "tools/base64.html", label: "Base64", dot: "#FF9A3C" },
    { href: "tools/jwt.html", label: "JWT Decoder", dot: "#B07EFF" },
    { href: "tools/diff.html", label: "Diff Checker", dot: "#5BA4FF" },
    { href: "tools/timestamp.html", label: "Date & Time Tools", dot: "#3DFFA0" },
    { href: "tools/hash.html", label: "Hash Generator", dot: "#22D9F0" },
    { href: "tools/color.html", label: "Color Converter", dot: "#B07EFF" },
];

function renderList() {
    const list = document.getElementById("list");
    list.innerHTML = "";
    QUICK_TOOLS.forEach(tool => {
        const a = document.createElement("a");
        a.className = "item";
        a.href = "#";
        a.innerHTML = `<span class="dot" style="background:${tool.dot}"></span><span>${tool.label}</span>`;
        a.addEventListener("click", (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: `${BASE_URL}/${tool.href}` });
            window.close();
        });
        list.appendChild(a);
    });
}

document.getElementById("openHome").addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: `${BASE_URL}/index.html` });
    window.close();
});

renderList();
