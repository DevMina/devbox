# DevBox browser extension

A Manifest V3 extension (Chrome, Edge, Brave, and other Chromium-based browsers) providing:

- **A popup** with quick access to 10 commonly-used DevBox tools, without needing a tab already open on the site.
- **Right-click actions on selected text** anywhere on the web — "Format as JSON," "Base64 Decode," "URL Decode," "Decode JWT," "Hash this text" — each opens the matching tool in a new tab with your selection already filled in and processed.

## How the handoff works

The extension can't write directly into the DevBox site's storage before the page loads (it's a different origin). Instead, it base64-encodes the selected text into a URL parameter (`?ext_prefill=...`) when opening the tool. The site already has a small bridge for this in `assets/shared.js` — it decodes that parameter and feeds it into the exact same internal mechanism the site's own tool-chaining ("Send to →") buttons use, then cleans the parameter out of the URL bar. One prefill mechanism serves both features.

## Installing it locally (for testing, or just for yourself)

1. Open `chrome://extensions` (or `edge://extensions`).
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked** and select this `devbox-extension` folder.
4. The DevBox icon should appear in your toolbar. Pin it for easy access.

Try it: select any JSON-looking text on any webpage, right-click, and choose **DevBox → Format as JSON**.

## Before publishing to the Chrome Web Store

A few things to do first, since this was built for local/personal use:

- **Icons are placeholder-quality** (programmatically generated, matching the site's colors but not hand-designed). Worth commissioning or designing proper ones before a public listing.
- **`host_permissions` is locked to `devmina.github.io/devbox`** — correct and intentional (least-privilege; the extension shouldn't need access to any other site). If the site ever moves to a custom domain, update this in `manifest.json`.
- Chrome Web Store review requires a **privacy policy** even for an extension like this that sends no data anywhere — a short page stating exactly that (selected text goes only into a URL opened directly to devmina.github.io, nothing is transmitted to any server the extension controls) is normally sufficient.
- Consider adding a few more context menu actions or popup shortcuts based on which tools people actually reach for once this is in real use — the current lists (5 context actions, 10 popup shortcuts) are a reasonable starting curation, not a hard limit.

## File structure

```
devbox-extension/
├── manifest.json      Extension configuration (Manifest V3)
├── background.js      Registers context menu items, opens tabs with the handoff
├── popup.html/popup.js  The toolbar popup UI
└── icons/              16/48/128px extension icons
```
